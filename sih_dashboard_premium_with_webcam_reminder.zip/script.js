// Script file created for webcam integration


// Webcam integration
const video = document.getElementById('webcam');
const enableCamButton = document.getElementById('enableCam');

if (enableCamButton) {
  enableCamButton.addEventListener('click', () => {
    navigator.mediaDevices.getUserMedia({ video: true })
      .then(stream => {
        video.srcObject = stream;
      })
      .catch(err => {
        console.error("Error accessing webcam: ", err);
      });
  });
}


// Reminder Modal functionality
const reminderModal = document.getElementById('reminderModal');
const setReminderBtn = document.getElementById('setReminder');
const closeReminderBtn = document.getElementById('closeReminder');
const reminderTimeInput = document.getElementById('reminderTime');

function openReminderModal() {
  if (reminderModal) {
    reminderModal.classList.remove('hidden');
  }
}

if (closeReminderBtn) {
  closeReminderBtn.addEventListener('click', () => {
    reminderModal.classList.add('hidden');
  });
}

if (setReminderBtn) {
  setReminderBtn.addEventListener('click', () => {
    const reminderTime = reminderTimeInput.value;
    if (reminderTime) {
      alert("Reminder set for: " + reminderTime);
    } else {
      alert("No time selected, reminder not set.");
    }
    reminderModal.classList.add('hidden');
  });
}

// Automatically open reminder modal when Live Visualization loads
document.addEventListener('DOMContentLoaded', () => {
  const liveSection = document.getElementById('live-visualization');
  if (liveSection) {
    const observer = new MutationObserver((mutations) => {
      mutations.forEach((mutation) => {
        if (mutation.target.style.display !== 'none' && !liveSection.classList.contains('hidden')) {
          openReminderModal();
        }
      });
    });
    observer.observe(liveSection, { attributes: true, attributeFilter: ['class', 'style'] });
  }
});
